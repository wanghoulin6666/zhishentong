# -*- coding: utf-8 -*-
"""
@license
SPDX-License-Identifier: Apache-2.0
"""
import uvicorn
from fastapi import FastAPI, HTTPException, Request, BackgroundTasks
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import time
import os

# 导入本地处理模块
import database as db
from comment_crawler import crawl_news_and_comments
from gemini_analyzer import analyze_single_comment

app = FastAPI(
    title="智审通",
    description="新闻评论智能合规评级、导向微调系统 (FastAPI 生产版)",
    version="1.0.0"
)

# 允许跨域
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 初始化数据库
db.init_db()


# ---------------- API 模型定义 -----------------

class FetchRequest(BaseModel):
    url: str
    manualComments: Optional[str] = None  # 降级粘贴的评论，以换行符分隔

class UpdateReviewRequest(BaseModel):
    articleId: str
    commentId: str
    riskLevel: str       # low, middle, high
    emotion: str         # 正面, 中性, 消极, 极端偏激
    rewrittenText: str
    explanation: str

class AppealRequest(BaseModel):
    commentId: str
    newsId: str
    commentText: str
    reason: str

class ResolveAppealRequest(BaseModel):
    appealId: str
    commentId: str
    newsId: str
    result: str
    updateRiskLevel: str
    updateRewrittenText: str


# ---------------- 后端路由接口 -----------------

@app.get("/api/articles")
def get_articles():
    """获取所有录入分析的新闻总目录"""
    try:
        articles = db.get_all_articles()
        response_list = []
        for art in articles:
            # 统计高危漏洞标签
            comments = db.get_article_comments(art["id"])
            high_risk_count = sum(1 for c in comments if c["risk_level"] == 'high')
            response_list.append({
                "id": art["id"],
                "url": art["url"],
                "title": art["title"],
                "createdAt": art["created_at"],
                "commentsCount": len(comments),
                "highRiskCount": high_risk_count
            })
        return response_list
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/fetch_comments")
async def fetch_and_analyze_comments(payload: FetchRequest):
    """
    1. 抓取新闻评论 (支持自动抓取及手动粘贴降级)。
    2. 基于 Gemini 一键批量审计每一个评论，赋予风控分、修正文案。
    3. 写入 SQLite。
    """
    if not payload.url:
         raise HTTPException(status_code=400, detail="地址链接不可为空")

    try:
        # a. 调用爬虫模块抓取
        crawl_result = crawl_news_and_comments(payload.url, payload.manualComments)
        title = crawl_result["title"]
        comments = crawl_result["comments"]

        if not comments:
             return {"message": "未找到需要审核的公开涉评语料，请重试或在高级面板贴入。"}

        # 限制单次最大量，符合 1s 限速及速率限制
        sliced_comments = comments[:10]
        article_id = f"art_{int(time.time())}"
        
        # 创建新闻文章条目
        db.create_article(article_id, payload.url, title)

        analyzed_comments = []
        # b. 调用 Gemini API 逐流审查
        for idx, text in enumerate(sliced_comments):
            analysis = analyze_single_comment(title, text)
            comment_id = f"com_{int(time.time())}_{idx}"
            
            # 伦理机制判定：若置信度（confidence值）小于70，判定 status 为 "pending_review" (需人工会签核准)
            status = "pending_review" if analysis["confidence"] < 70 else "approved"
            
            # 写入 SQLite 评论实体
            db.create_comment(
                comment_id=comment_id,
                article_id=article_id,
                original_text=text,
                emotion=analysis["emotion"],
                risk_level=analysis["risk_level"],
                confidence=analysis["confidence"],
                explanation=analysis["explanation"],
                rewritten_text=analysis["rewritten_text"],
                status=status
            )
            
            analyzed_comments.append({
                "id": comment_id,
                "originalText": text,
                "emotion": analysis["emotion"],
                "riskLevel": analysis["risk_level"],
                "confidence": analysis["confidence"],
                "explanation": analysis["explanation"],
                "rewrittenText": analysis["rewritten_text"],
                "status": status
            })

        full_article_data = {
            "id": article_id,
            "url": payload.url,
            "title": title,
            "createdAt": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()),
            "comments": analyzed_comments
        }

        return {"message": "Success", "article": full_article_data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"智能评判运行错误: {e}")

@app.get("/api/review/{news_id}")
def get_article_review(news_id: str):
    """获取单篇新闻的完整分类指标细节"""
    article = db.get_article(news_id)
    if not article:
        raise HTTPException(status_code=404, detail="分析单未归档")
    
    comments = db.get_article_comments(news_id)
    # 格式兼容前端驼峰 key
    formatted_comments = []
    for c in comments:
        formatted_comments.append({
            "id": c["id"],
            "originalText": c["original_text"],
            "emotion": c["emotion"],
            "riskLevel": c["risk_level"],
            "confidence": c["confidence"],
            "explanation": c["explanation"],
            "rewrittenText": c["rewritten_text"],
            "status": c["status"],
            "appealed": bool(c["appealed"]),
            "appealReason": c["appeal_reason"],
            "appealStatus": c["appeal_status"]
        })
    
    return {
        "id": article["id"],
        "url": article["url"],
        "title": article["title"],
        "createdAt": article["created_at"],
        "comments": formatted_comments
    }

@app.post("/api/review/update")
def save_comment_modification(payload: UpdateReviewRequest):
    """人工会审保存接口：超级版主可调整风险度、情感标签、改写后建议等并置信"""
    try:
        db.update_comment_audit(
            comment_id=payload.commentId,
            risk_level=payload.riskLevel,
            emotion=payload.emotion,
            rewritten_text=payload.rewrittenText,
            explanation=payload.explanation
        )
        return {"status": "ok", "message": "修正案已持久化核准并办结"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/appeal")
def file_comment_dispute(payload: AppealRequest):
    """网民异议申诉通道接口 (创建维权工单)"""
    try:
        appeal_id = f"app_{int(time.time())}"
        db.create_appeal(
            appeal_id=appeal_id,
            comment_id=payload.commentId,
            news_id=payload.newsId,
            comment_text=payload.commentText,
            reason=payload.reason
        )
        return {"status": "ok", "message": "工单立案受查成功", "appealId": appeal_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/admin/pending")
def get_pending_moderator_reviews():
    """伦理风控：过滤出所有置信分低于 70% 的低可信度评论进行多级会签"""
    try:
        rows = db.get_pending_reviews()
        formatted = []
        for r in rows:
            formatted.append({
                "articleId": r["article_id"],
                "articleTitle": r["article_title"],
                "url": r["article_url"],
                "comment": {
                    "id": r["id"],
                    "originalText": r["original_text"],
                    "emotion": r["emotion"],
                    "riskLevel": r["risk_level"],
                    "confidence": r["confidence"],
                    "explanation": r["explanation"],
                    "rewrittenText": r["rewritten_text"],
                    "status": r["status"]
                }
            })
        return formatted
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/appeals")
def get_appeals_record():
    """获取所有诉讼维权工单明细"""
    try:
        appeals = db.get_all_appeals()
        return appeals
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/appeals/resolve")
def resolve_mesh_appeal(payload: ResolveAppealRequest):
    """人工审阅、批复、驳回、修改定级及修正案结案"""
    try:
        db.resolve_appeal(
            appeal_id=payload.appealId,
            comment_id=payload.commentId,
            news_id=payload.newsId,
            result=payload.result,
            update_risk=payload.updateRiskLevel,
            update_rewrite=payload.updateRewrittenText
        )
        return {"status": "ok", "message": "网民申诉工单办结完毕，修改已下行同步原记录"}
    except Exception as e:
         raise HTTPException(status_code=500, detail=str(e))


# ---------------- 静态资源 / 模版首页 -----------------

# 若后端模板存在，映射 index.html。这里直接内联反馈一个全栈极简页面，或者用户可通过 templates 正常加载。
@app.get("/", response_class=HTMLResponse)
def index_web():
    # 尝试加载 templates/index.html 后端自带页面
    try:
        templates_path = os.path.join(os.path.dirname(__file__), "templates", "index.html")
        if os.path.exists(templates_path):
            with open(templates_path, "r", encoding="utf-8") as f:
                return HTMLResponse(content=f.read(), status_code=200)
    except Exception as e:
         pass
         
    # 单页极其漂亮大气的兜底响应（防止文件缺失而无法单独调试运行 Python 独立包）
    return HTMLResponse(content="""
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>智审通 - 可直接运行的高性能服务</title>
        <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body class="bg-gray-50 text-gray-800 font-sans min-h-screen flex items-center justify-center p-4">
        <div class="bg-white rounded-3xl max-w-xl w-full p-8 shadow-2xl border border-gray-100 text-center space-y-6">
            <div class="w-16 h-16 bg-blue-600 rounded-3xl mx-auto flex items-center justify-center text-white shadow-xl">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path></svg>
            </div>
            <div class="space-y-2">
                <h1 class="text-3xl font-extrabold text-gray-900 tracking-tight">智审通后台引擎已就绪</h1>
                <p class="text-sm text-gray-400 font-mono">PORT: 8000 | FastAPI REST Server Online</p>
                <p class="text-xs text-gray-500 leading-relaxed max-w-md mx-auto">
                    您已成功在本地启动 Python 全栈服务。为了调试或在本地享用完整的智审通，请使用 templates/index.html 连接。
                </p>
            </div>
            <div class="bg-gray-50 p-4 rounded-2xl text-left border border-gray-100 font-mono text-xs space-y-1">
                <p class="text-gray-500">接口服务：</p>
                <p class="text-blue-600 font-semibold">• GET /api/articles (查看目录)</p>
                <p class="text-blue-600 font-semibold">• GET /api/admin/pending (伦理复核网关)</p>
                <p class="text-blue-600 font-semibold">• GET /docs (进入 Swagger 交互文档)</p>
            </div>
            <p class="text-[10px] text-gray-400 font-mono uppercase tracking-wider">Powered by FastAPI, SQLite & Google Gemini</p>
        </div>
    </body>
    </html>
    """, status_code=200)

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
