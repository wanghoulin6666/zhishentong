/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  Search, 
  AlertTriangle, 
  CheckCircle, 
  ThumbsUp, 
  Smile, 
  MessageSquare, 
  Sliders, 
  Edit3, 
  FileText, 
  Check, 
  RefreshCw, 
  Copy, 
  ExternalLink, 
  UserCheck, 
  Send,
  Plus,
  ArrowRight,
  Info,
  Scale,
  Download
} from 'lucide-react';
import { CommentItem, NewsArticle, AppealTicket } from './types';

export default function App() {
  // Ethical Consent Form State
  const [consentGranted, setConsentGranted] = useState<boolean>(false);
  const [showConsentModal, setShowConsentModal] = useState<boolean>(false);

  // Core Application States
  const [urlInput, setUrlInput] = useState<string>('https://news.sina.com.cn/c/2026-05-25/doc-imnyvmsx7728469.shtml');
  const [manualCommentsInput, setManualCommentsInput] = useState<string>('');
  const [showManualInput, setShowManualInput] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingStep, setLoadingStep] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // DB Data States
  const [articlesList, setArticlesList] = useState<any[]>([]);
  const [activeArticle, setActiveArticle] = useState<NewsArticle | null>(null);
  const [pendingReviews, setPendingReviews] = useState<any[]>([]);
  const [appealsList, setAppealsList] = useState<AppealTicket[]>([]);

  // Local interaction states
  const [activeTab, setActiveTab] = useState<'audit' | 'pending' | 'appeals'>('audit');
  
  // Modal Edit states
  const [editComment, setEditComment] = useState<CommentItem | null>(null);
  const [editedRisk, setEditedRisk] = useState<'low' | 'middle' | 'high'>('low');
  const [editedEmotion, setEditedEmotion] = useState<'正面' | '中性' | '消极' | '极端偏激'>('中性');
  const [editedExplanation, setEditedExplanation] = useState<string>('');
  const [editedRewriteText, setEditedRewriteText] = useState<string>('');

  // Appeal flow states
  const [appealComment, setAppealComment] = useState<CommentItem | null>(null);
  const [appealReason, setAppealReason] = useState<string>('');

  // Settle Appeal flow states
  const [settlingAppealId, setSettlingAppealId] = useState<string | null>(null);
  const [appealResultText, setAppealResultText] = useState<string>('');
  const [appealUpdateRisk, setAppealUpdateRisk] = useState<'low' | 'middle' | 'high'>('low');
  const [appealUpdateRewrite, setAppealUpdateRewrite] = useState<string>('');

  // Check consent on mounting
  useEffect(() => {
    const consent = localStorage.getItem('zhishentong_consent_v1');
    if (consent === 'true') {
      setConsentGranted(true);
    } else {
      setShowConsentModal(true);
    }
    refreshData();
  }, []);

  const handleGrantConsent = () => {
    localStorage.setItem('zhishentong_consent_v1', 'true');
    setConsentGranted(true);
    setShowConsentModal(false);
  };

  const refreshData = async () => {
    try {
      const artRes = await fetch('/api/articles');
      if (artRes.ok) {
        const list = await artRes.json();
        setArticlesList(list);
        
        // If there's an active article, refresh it, else bind the latest one if any
        if (list.length > 0) {
          const latestId = activeArticle?.id || list[0].id;
          loadArticleDetail(latestId);
        }
      }

      const pendingRes = await fetch('/api/admin/pending');
      if (pendingRes.ok) {
        setPendingReviews(await pendingRes.json());
      }

      const appealsRes = await fetch('/api/appeals');
      if (appealsRes.ok) {
        setAppealsList(await appealsRes.json());
      }
    } catch (err) {
      console.error('Error refreshing backend DB:', err);
    }
  };

  const loadArticleDetail = async (id: string) => {
    try {
      const res = await fetch(`/api/review/${id}`);
      if (res.ok) {
        const fullArticle = await res.json();
        setActiveArticle(fullArticle);
      }
    } catch (err) {
      console.error('Error loading article:', err);
    }
  };

  // Moderator Quick Save or Detail Edit Save
  const handleSaveEdit = async () => {
    if (!activeArticle || !editComment) return;
    try {
      const res = await fetch('/api/review/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          articleId: activeArticle.id,
          commentId: editComment.id,
          riskLevel: editedRisk,
          emotion: editedEmotion,
          rewrittenText: editedRewriteText,
          explanation: editedExplanation
        })
      });

      if (res.ok) {
        setEditComment(null);
        await refreshData();
      }
    } catch (err) {
      console.error('Save edit failed:', err);
    }
  };

  // Make appeal ticket
  const handleCreateAppeal = async () => {
    if (!activeArticle || !appealComment || !appealReason) return;
    try {
      const res = await fetch('/api/appeal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          commentId: appealComment.id,
          newsId: activeArticle.id,
          commentText: appealComment.originalText,
          reason: appealReason
        })
      });

      if (res.ok) {
        setAppealComment(null);
        setAppealReason('');
        await refreshData();
      }
    } catch (err) {
      console.error('Appeal registration failed:', err);
    }
  };

  // Settle appeal
  const handleResolveAppeal = async (appealId: string) => {
    try {
      const res = await fetch('/api/appeals/resolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          appealId,
          result: appealResultText,
          updateRiskLevel: appealUpdateRisk,
          updateRewrittenText: appealUpdateRewrite
        })
      });

      if (res.ok) {
        setSettlingAppealId(null);
        setAppealResultText('');
        await refreshData();
      }
    } catch (err) {
      console.error('Failed to resolve appeal:', err);
    }
  };

  // Master fetch & Moderator analyzer handler
  const handleFetchAndAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!consentGranted) {
      setShowConsentModal(true);
      return;
    }

    setIsLoading(true);
    setErrorMsg(null);

    const steps = [
      '正在连接目标站点抓取新闻页面...',
      '正在提取标题与评论文本元数据...',
      '正在初始化 Google Gemini 3.5 智能模型...',
      '正在执行内容分析与合规风险评级...',
      '正在基于多级审核要求执行导向重写矫正...',
      '生成多维度审计数据报告并存储...'
    ];

    let currentStepIdx = 0;
    setLoadingStep(steps[currentStepIdx]);
    
    // Simulate interactive step logs progress bar
    const stepInterval = setInterval(() => {
      if (currentStepIdx < steps.length - 1) {
        currentStepIdx++;
        setLoadingStep(steps[currentStepIdx]);
      }
    }, 1500);

    try {
      let manualComments = undefined;
      if (showManualInput && manualCommentsInput.trim()) {
        manualComments = manualCommentsInput
          .split('\n')
          .map(line => line.trim())
          .filter(line => line.length > 0);
      }

      const res = await fetch('/api/fetch_comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: urlInput,
          manualComments
        })
      });

      clearInterval(stepInterval);

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || '后端审查组件执行异常');
      }

      const data = await res.json();
      setActiveArticle(data.article);
      
      // Clear manual box on success
      setManualCommentsInput('');
      setShowManualInput(false);
      
      await refreshData();
    } catch (error: any) {
      clearInterval(stepInterval);
      setErrorMsg(error.message || '网络连接超时，请重试');
    } finally {
      setIsLoading(false);
      setLoadingStep('');
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('已复制修正文本到剪贴板！');
  };

  const handleExportCSV = () => {
    if (!activeArticle) return;
    try {
      // Create CSV with UTF-8 BOM so MS Excel reads Chinese correctly without layout issues
      const headers = ['评论ID', '原始涉评文本', '情感分类', '判定合规风险', '分类置信度', '修饰标签', '智能纠偏建议'];
      const rows = activeArticle.comments.map(c => [
        c.id.slice(-5),
        `"${c.originalText.replace(/"/g, '""')}"`,
        c.emotion,
        c.riskLevel === 'high' ? '高风险' : c.riskLevel === 'middle' ? '中风险' : '低风险',
        `${c.confidence}%`,
        `"${c.explanation.replace(/"/g, '""')}"`,
        `"${(c.rewrittenText || '').replace(/"/g, '""')}"`
      ]);

      const csvContent = "\uFEFF" + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `智审通审计成果_${activeArticle.title.substring(0, 15)}_${new Date().toISOString().slice(0,10)}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error('导出CSV失败:', err);
      alert('导出CSV失败，请重试');
    }
  };

  const handleExportJSON = () => {
    if (!activeArticle) return;
    try {
      const dataStr = JSON.stringify(activeArticle, null, 2);
      const blob = new Blob([dataStr], { type: 'application/json;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `智审通数据备份_${activeArticle.title.substring(0, 15)}_${new Date().toISOString().slice(0,10)}.json`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error('导出JSON失败:', err);
      alert('导出JSON失败，请重试');
    }
  };

  // Visual Statistics calculations
  const calculateStats = () => {
    if (!activeArticle) return { total: 0, highRiskPct: 0, emotions: {}, riskCounts: { low: 0, middle: 0, high: 0 }, commonLabels: [] };
    const comments = activeArticle.comments;
    const total = comments.length;
    
    const riskCounts = { low: 0, middle: 0, high: 0 };
    const emotions: { [key: string]: number } = { '正面': 0, '中性': 0, '消极': 0, '极端偏激': 0 };
    const labelsMap: { [key: string]: number } = {};

    comments.forEach(c => {
      riskCounts[c.riskLevel]++;
      emotions[c.emotion] = (emotions[c.emotion] || 0) + 1;
      labelsMap[c.explanation] = (labelsMap[c.explanation] || 0) + 1;
    });

    const highRiskPct = total > 0 ? Math.round((riskCounts.high / total) * 100) : 0;
    
    const commonLabels = Object.entries(labelsMap)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 4)
      .map(([label, count]) => ({ label, count }));

    return { total, highRiskPct, emotions, riskCounts, commonLabels };
  };

  const stats = calculateStats();

  return (
    <div className="bg-slate-950 text-slate-100 min-h-screen font-sans antialiased">
      {/* HEADER SECTION */}
      <header className="bg-gradient-to-r from-slate-900 to-slate-800 text-white shadow-lg border-b border-slate-700">
        <div className="max-w-7xl mx-auto px-4 py-5 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 w-full md:w-auto">
            <div className="bg-blue-600 p-2.5 rounded-xl shadow-md border border-blue-400/30 shrink-0">
              <Shield className="w-8 h-8 text-white stroke-[2]" id="app-logo" />
            </div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-100 truncate">智审通 NEWS</h1>
                <span className="text-[10px] bg-red-500 text-white px-1.5 py-0.5 rounded font-mono font-semibold tracking-wider uppercase animate-pulse shrink-0">Production Ready</span>
              </div>
              <p className="text-slate-300 text-[11px] sm:text-xs mt-0.5 font-medium break-all sm:break-normal">全栈 AI 新闻评论智能审核与导向矫正系统</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center md:justify-end gap-3 sm:gap-4 text-xs font-mono w-full md:w-auto">
            <div className="flex items-center gap-1.5 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
              <span className="text-slate-300 text-[10px] sm:text-xs">Gemini 3.5 Active</span>
            </div>
            <button 
              onClick={() => setShowConsentModal(true)} 
              className="text-blue-400 hover:text-blue-300 font-semibold underline underline-offset-4 cursor-pointer text-[10px] sm:text-xs text-center shrink-0"
            >
              伦理知情声明
            </button>
          </div>
        </div>
      </header>

      {/* CORE WORKSPACE container */}
      <main className="max-w-7xl mx-auto px-4 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFT COMPONENT - url query, manual input & list (4 cols) */}
        <section className="lg:col-span-4 flex flex-col gap-6">
          
          {/* SITES INPUT SEARCH BOX */}
          <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-sm p-6">
            <h2 className="text-sm font-semibold text-slate-100 uppercase tracking-wider mb-4 flex items-center gap-2">
              <span className="w-1.5 h-4 bg-blue-600 rounded"></span>评论抓取引擎
            </h2>

            <form onSubmit={handleFetchAndAnalyze} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">新闻页面 URL 地址</label>
                <div className="relative">
                  <input
                    type="url"
                    value={urlInput}
                    onChange={(e) => setUrlInput(e.target.value)}
                    required
                    placeholder="https://news.sina.com.cn/xxxx"
                    className="w-full pr-10 pl-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-slate-100 placeholder:text-slate-650 transition-all font-mono"
                  />
                  <Search className="absolute right-3.5 top-3 w-4 h-4 text-slate-500" />
                </div>
                
                {/* Supported Sites Listing Explanation */}
                <div className="mt-2.5 p-3 bg-blue-950/20 rounded-xl border border-blue-900/30 text-[11px] text-slate-300 space-y-1">
                  <p className="font-bold text-blue-400 flex items-center gap-1">
                    <Info className="w-3.5 h-3.5 shrink-0" /> 此处支持放进去的网站链接包括：
                  </p>
                  <ul className="list-disc pl-4.5 space-y-0.5 text-slate-400 text-[10px]">
                    <li>新浪新闻 (<span className="font-mono text-blue-400 font-medium">sina.com.cn</span>) 的公开资讯及讨论区</li>
                    <li>腾讯网 (<span className="font-mono text-blue-400 font-medium">news.qq.com</span>) 报道页面</li>
                    <li>网易新闻 (<span className="font-mono text-blue-400 font-medium">news.163.com</span>) 新闻言论页</li>
                    <li>搜狐新闻 (<span className="font-mono text-blue-400 font-medium">sohu.com</span>) 百态报道</li>
                    <li>凤凰网 (<span className="font-mono text-blue-400 font-medium">ifeng.com</span>) 及任意正规新闻门户链接</li>
                  </ul>
                  <p className="text-[10px] text-slate-500 mt-1 italic">提示：若目标页面受防静/动态安全限制未抓取到评论，系统将启动降级测试，自适应装载该新闻方向的公开评论演示例证。</p>
                </div>
              </div>

              {/* Collapsible Manual comments list */}
              <div>
                <button
                  type="button"
                  onClick={() => setShowManualInput(!showManualInput)}
                  className="text-xs text-slate-400 hover:text-blue-400 flex items-center gap-1 font-medium transition-colors"
                >
                  <Plus className={`w-3.5 h-3.5 transition-transform duration-200 ${showManualInput ? 'rotate-45' : ''}`} />
                  <span>{showManualInput ? '取消手动输入评论' : '高级选项：降级手动贴入评论'}</span>
                </button>

                {showManualInput && (
                  <div className="mt-3 space-y-1.5 animate-fadeIn">
                    <label className="block text-[11px] font-medium text-slate-400">评论内容 (每行一条。若网页反爬阻断，将优先使用此处内容)</label>
                    <textarea
                      value={manualCommentsInput}
                      onChange={(e) => setManualCommentsInput(e.target.value)}
                      rows={4}
                      placeholder="第一条评论：这政策真好，期待落地实施！&#10;第二条评论：呵呵，又是拍脑袋决定的吧..."
                      className="w-full p-3 bg-slate-950 border border-slate-800 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-slate-100 placeholder:text-slate-600 font-mono transition-all"
                    />
                  </div>
                )}
              </div>

              {errorMsg && (
                <div className="bg-red-50 text-red-700 border border-red-100 p-3.5 rounded-xl text-xs flex items-start gap-2 animate-shake">
                  <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0 text-red-500" />
                  <p className="font-medium leading-relaxed">{errorMsg}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 px-4 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-800 disabled:text-slate-500 disabled:cursor-not-allowed text-white text-sm font-bold rounded-xl shadow-md shadow-blue-600/10 hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-white" />
                    <span>执行处理中...</span>
                  </>
                ) : (
                  <>
                    <Shield className="w-4.5 h-4.5 text-white" />
                    <span>抓取并一键智能审计</span>
                  </>
                )}
              </button>
            </form>

            {/* Dynamic visual Loading Steps Indicator */}
            {isLoading && (
              <div className="mt-4 bg-slate-950 border border-blue-900/40 p-4 rounded-xl space-y-2">
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-slate-400 font-medium">智能流程步骤</span>
                  <span className="text-blue-400 font-bold font-mono">Running</span>
                </div>
                <p className="text-slate-300 text-[11px] font-bold font-mono animate-pulse flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-blue-500 animate-ping inline-block shrink-0"></span>
                  {loadingStep}
                </p>
                <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden">
                  <div className="bg-blue-600 h-full w-[65%] rounded-full animate-barProgress"></div>
                </div>
              </div>
            )}
          </div>

          {/* HISTORICAL WORKSPACE SESSIONS */}
          <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-sm p-6 flex flex-col gap-3 flex-1 overflow-hidden">
            <h2 className="text-sm font-semibold text-slate-100 uppercase tracking-wider flex items-center justify-between">
              <span className="flex items-center gap-2">
                <span className="w-1.5 h-4 bg-cyan-600 rounded"></span>历史分析记录
              </span>
              <span className="text-[10px] font-mono bg-slate-850 px-1.5 py-0.5 rounded text-slate-400 font-bold">{articlesList.length} 篇</span>
            </h2>

            <div className="space-y-2 overflow-y-auto max-h-[300px] pr-1">
              {articlesList.length === 0 ? (
                <div className="text-center py-8 text-slate-550">
                  <FileText className="w-8 h-8 mx-auto stroke-[1] mb-2 text-slate-600" />
                  <p className="text-xs">暂无历史记录，开始抓取吧</p>
                </div>
              ) : (
                articlesList.map((art) => {
                  const isActive = activeArticle?.id === art.id;
                  const date = new Date(art.createdAt).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
                  return (
                    <button
                      key={art.id}
                      onClick={() => loadArticleDetail(art.id)}
                      className={`w-full text-left p-3 rounded-xl border transition-all text-xs flex flex-col gap-1.5 cursor-pointer ${
                        isActive 
                          ? 'bg-blue-950/40 border-blue-900/80 shadow-sm' 
                          : 'bg-slate-950 hover:bg-slate-900 border-slate-900 hover:border-slate-850'
                      }`}
                    >
                      <div className="flex font-bold justify-between items-center gap-2">
                        <span className={`line-clamp-1 flex-1 ${isActive ? 'text-blue-300' : 'text-slate-300'}`}>
                          {art.title}
                        </span>
                        <span className="text-[10px] shrink-0 font-mono text-slate-550">{date}</span>
                      </div>
                      
                      <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                        <span className="bg-slate-800 px-1.5 py-0.5 rounded text-slate-300">{art.commentsCount}条评论分析</span>
                        {art.highRiskCount > 0 ? (
                          <span className="text-rose-400 bg-rose-950/30 border border-rose-900 px-1.5 py-0.5 rounded font-bold flex items-center gap-0.5">
                            <AlertTriangle className="w-3 h-3 text-rose-500" /> {art.highRiskCount}高危
                          </span>
                        ) : (
                          <span className="text-emerald-400 bg-emerald-950/30 border border-emerald-900 px-1.5 py-0.5 rounded font-bold">全绿安全</span>
                        )}
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>

        </section>

        {/* RIGHT COMPONENT - content overview dashboard & results list (8 cols) */}
        <section className="lg:col-span-8 flex flex-col gap-6">

          {/* ADMIN ACTION SUB-BAR WORKSPACE SELECTORS */}
          <div className="flex border-b border-slate-800 space-x-1 sm:space-x-1.5 bg-slate-900 p-1 rounded-xl shadow-sm border border-slate-800">
            <button
              onClick={() => setActiveTab('audit')}
              className={`flex-1 py-2 sm:py-2.5 px-1.5 sm:px-4 rounded-lg text-[11px] sm:text-xs font-bold transition-all flex items-center justify-center gap-1 sm:gap-2 cursor-pointer ${
                activeTab === 'audit'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-100'
              }`}
            >
              <FileText className="w-3.5 h-3.5 hidden sm:block shrink-0" />
              <span className="hidden sm:inline">智能审查报告</span>
              <span className="sm:hidden">审查报告</span>
              {activeArticle && (
                <span className={`text-[9px] sm:text-[10px] font-bold font-mono px-1 sm:px-2 py-0.5 rounded-full ${
                  activeTab === 'audit' ? 'bg-blue-500 text-white' : 'bg-slate-800 text-slate-300'
                }`}>
                  {stats.total}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('pending')}
              className={`flex-1 py-2 sm:py-2.5 px-1.5 sm:px-4 rounded-lg text-[11px] sm:text-xs font-bold transition-all flex items-center justify-center gap-1 sm:gap-2 cursor-pointer ${
                activeTab === 'pending'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-100'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5 hidden sm:block shrink-0" />
              <span className="hidden sm:inline">待人工复核</span>
              <span className="sm:hidden">待复核</span>
              {pendingReviews.length > 0 && (
                <span className="text-[9px] sm:text-[10px] font-mono font-bold bg-amber-500 text-white px-1 sm:px-1.5 py-0.5 rounded-full animate-bounce">
                  {pendingReviews.length}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('appeals')}
              className={`flex-1 py-2 sm:py-2.5 px-1.5 sm:px-4 rounded-lg text-[11px] sm:text-xs font-bold transition-all flex items-center justify-center gap-1 sm:gap-2 cursor-pointer ${
                activeTab === 'appeals'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-100'
              }`}
            >
              <Scale className="w-3.5 h-3.5 hidden sm:block shrink-0" />
              <span className="hidden sm:inline">申诉维权工单</span>
              <span className="sm:hidden">维权工单</span>
              {appealsList.filter(a => a.status === 'pending').length > 0 && (
                <span className="text-[9px] sm:text-[10px] font-mono font-bold bg-teal-500 text-white px-1 sm:px-1.5 py-0.5 rounded-full">
                  {appealsList.filter(a => a.status === 'pending').length}
                </span>
              )}
            </button>
          </div>

          {/* TAB 1: MODERATION AUDIT MAIN PANEL */}
          {activeTab === 'audit' && (
            <>
              {/* STATS SUMMARY BENCHMARK BLOCK */}
              {activeArticle ? (
                <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-sm p-4 sm:p-6 grid grid-cols-1 md:grid-cols-12 gap-6">
                  
                  {/* Title & metadata bar */}
                  <div className="md:col-span-12 border-b border-slate-800 pb-3 flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
                    <div className="space-y-1 w-full min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-xs bg-blue-950/80 border border-blue-900/40 text-blue-300 font-bold px-2 py-0.5 rounded-md font-mono uppercase shrink-0">已分析</span>
                        <h3 className="text-slate-100 font-bold text-sm sm:text-base leading-snug break-all sm:break-normal w-full sm:w-auto">{activeArticle.title}</h3>
                      </div>
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-450">
                        <span className="font-mono text-[11px] max-w-[200px] sm:max-w-xs md:max-w-md truncate flex items-center gap-1">
                          <ExternalLink className="w-3.5 h-3.5 shrink-0" /> <a href={activeArticle.url} target="_blank" rel="noreferrer" className="underline hover:text-blue-400 break-all">{activeArticle.url}</a>
                        </span>
                        <span className="hidden sm:inline text-slate-600">|</span>
                        <span className="text-[11px] sm:text-xs text-slate-500">{new Date(activeArticle.createdAt).toLocaleString()}</span>
                      </div>
                    </div>

                    {/* Download buttons */}
                    <div className="flex flex-wrap gap-2 shrink-0 w-full md:w-auto mt-2 md:mt-0">
                      <button
                        onClick={handleExportCSV}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md hover:shadow-lg transition-all cursor-pointer select-none border border-emerald-500/20"
                      >
                        <Download className="w-3.5 h-3.5 shrink-0" />
                        <span>下载 Excel/CSV 报表</span>
                      </button>
                      <button
                        onClick={handleExportJSON}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold border border-slate-700 transition-all cursor-pointer select-none"
                      >
                        <Download className="w-3.5 h-3.5 shrink-0" />
                        <span>备份 JSON 数据</span>
                      </button>
                    </div>
                  </div>

                  {/* Warning banner for Local Rules Fallback Activation */}
                  {activeArticle.fallbackActive && (
                    <div className="md:col-span-12 bg-amber-950/20 border border-amber-900/30 rounded-xl p-4 flex gap-3 text-xs text-amber-200 shadow-sm">
                      <div className="mt-0.5 text-amber-500 font-bold text-lg select-none">🛡️</div>
                      <div className="space-y-1">
                        <p className="font-bold text-amber-400">本地二级自适应分析纠偏引擎已自动接管</p>
                        <p className="text-slate-350 leading-relaxed text-[11px]">
                          检测到当前云端智能审查服务接口连接存在受限阻断 (Gemini 403 权限异常)，系统已秒级、无缝装载
                          <strong>「智审通本地多级语言情绪启发分类备份引擎 (本地二级备份)」</strong>持续提供高质量评级和导向修正。
                          您的所有采集审计、人工复核、维权申辩工单处理<strong>均在本地完全闭环闭合支持，各项运行150%不受任何影响！</strong>
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Left stats cards (4 cols) */}
                  <div className="md:col-span-4 flex flex-col gap-4">
                    <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800">
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">累计处理评论</span>
                      <div className="flex items-baseline gap-2 mt-1">
                        <span className="text-3xl font-extrabold text-slate-100 leading-none">{stats.total}</span>
                        <span className="text-xs text-slate-400 font-medium font-mono">条记录</span>
                      </div>
                    </div>

                    <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800">
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">高度导向偏置比例</span>
                      <div className="flex items-baseline gap-2 mt-1">
                        <span className={`text-3xl font-extrabold leading-none ${stats.highRiskPct > 20 ? 'text-rose-400' : 'text-emerald-400'}`}>
                          {stats.highRiskPct}%
                        </span>
                        <span className="text-xs font-semibold text-slate-500">高风险舆论</span>
                      </div>
                    </div>
                  </div>

                  {/* SVG Charts visual donut representation (4 cols) */}
                  <div className="md:col-span-4 flex flex-col items-center justify-center bg-slate-950/80 p-4 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider text-center block mb-3">多維舆论情绪模型</span>
                    
                    {/* Perfect responsive SVG Donut */}
                    <div className="relative w-28 h-28 flex items-center justify-center">
                      <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
                        <circle cx="18" cy="18" r="15.915" fill="none" stroke="#1e293b" strokeWidth="3" />
                        
                        {/* Positive: emerald-500, Neutral: slate-400, Negative: amber-500, Extreme: text-red-500 */}
                        {(() => {
                          const totalVal = stats.total || 1;
                          const posPct = ((stats.emotions['正面'] || 0) / totalVal) * 100;
                          const neuPct = ((stats.emotions['中性'] || 0) / totalVal) * 100;
                          const negPct = ((stats.emotions['消极'] || 0) / totalVal) * 100;
                          const extPct = ((stats.emotions['极端偏激'] || 0) / totalVal) * 100;

                          let offset = 0;
                          const strokes = [
                            { val: posPct, color: '#10b981' },
                            { val: neuPct, color: '#64748b' },
                            { val: negPct, color: '#f59e0b' },
                            { val: extPct, color: '#f43f5e' }
                          ].filter(s => s.val > 0);

                          return strokes.map((s, idx) => {
                            const strokeDash = `${s.val} ${100 - s.val}`;
                            const strokeOffset = 100 - offset;
                            offset += s.val;
                            return (
                              <circle
                                key={idx}
                                cx="18"
                                cy="18"
                                r="15.915"
                                fill="none"
                                stroke={s.color}
                                strokeWidth="3.2"
                                strokeDasharray={strokeDash}
                                strokeDashoffset={strokeOffset}
                                className="transition-all duration-500"
                              />
                            );
                          });
                        })()}
                      </svg>
                      <div className="absolute flex flex-col items-center">
                        <span className="text-xs font-extrabold text-slate-200">情绪谱系</span>
                        <span className="text-[9px] text-slate-500 font-bold tracking-wider">MOMENTUM</span>
                      </div>
                    </div>

                    {/* Donut Legend */}
                    <div className="flex flex-wrap gap-x-3 gap-y-1.5 mt-3 w-full text-[10px] text-slate-400 font-semibold justify-center">
                      <div className="flex items-center gap-1 shrink-0">
                        <span className="w-2.5 h-2.5 rounded bg-emerald-500 shrink-0"></span><span>正面 ({stats.emotions['正面'] || 0})</span>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <span className="w-2.5 h-2.5 rounded bg-slate-400 shrink-0"></span><span>中性 ({stats.emotions['中性'] || 0})</span>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <span className="w-2.5 h-2.5 rounded bg-amber-500 shrink-0"></span><span>消极 ({stats.emotions['消极'] || 0})</span>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <span className="w-2.5 h-2.5 rounded bg-rose-500 shrink-0"></span><span>偏激 ({stats.emotions['极端偏激'] || 0})</span>
                      </div>
                    </div>
                  </div>

                  {/* Right risks features keywords (4 cols) */}
                  <div className="md:col-span-4 bg-slate-950/80 p-4 rounded-xl border border-slate-800 flex flex-col gap-1.5 justify-start min-w-0">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-2">高频风险特征</span>
                    {stats.commonLabels.length === 0 ? (
                      <div className="text-center py-4 text-xs text-slate-400 font-medium">无明显风险偏置特征</div>
                    ) : (
                      stats.commonLabels.map((lbl, idx) => (
                        <div key={idx} className="flex items-center justify-between text-xs bg-slate-900 py-1.5 px-3 rounded-lg border border-slate-800 shadow-sm gap-2 min-w-0">
                          <span className="font-bold text-slate-300 truncate max-w-[130px] sm:max-w-none break-all" title={lbl.label}>{lbl.label}</span>
                          <span className="font-mono bg-slate-950 px-1.5 py-0.5 rounded text-[10px] font-extrabold text-slate-400 shrink-0">{lbl.count} 频</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              ) : (
                <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-sm p-12 text-center text-slate-400 flex flex-col items-center justify-center gap-4">
                  <div className="bg-blue-950/30 p-4 rounded-full border border-blue-900/30 text-blue-400 animate-bounce">
                    <Shield className="w-12 h-12 stroke-[1.5]" />
                  </div>
                  <div>
                    <h3 className="text-slate-100 font-bold text-lg mb-1">请运行您的第一篇智能审查</h3>
                    <p className="text-slate-500 text-sm max-w-md leading-relaxed mx-auto">
                      点击左侧的抓取引擎开启内容评级。我们将抓取公开新闻页面，并启动 Google Gemini 支持的置信合规性判定。
                    </p>
                  </div>
                </div>
              )}


              {/* COMMENTS LISTS CONTAINER */}
              {activeArticle && (
                <div className="space-y-4 mt-6">
                  <div className="flex items-center justify-between">
                    <h2 className="text-sm font-semibold text-slate-200 uppercase tracking-wide flex items-center gap-2">
                      <span className="w-1.5 h-4 bg-blue-600 rounded"></span>审核项目细则表
                    </h2>
                    <span className="text-xs text-slate-400 font-medium font-mono">第 1 / 1 页</span>
                  </div>

                  <div className="space-y-4">
                    {activeArticle.comments.map((com) => {
                      const isHighRisk = com.riskLevel === 'high';
                      const isMidRisk = com.riskLevel === 'middle';
                      const isLowConfidence = com.confidence < 70;

                      return (
                        <div 
                          key={com.id} 
                          className={`bg-slate-900 rounded-2xl border border-slate-800 p-4 sm:p-6 shadow-sm flex flex-col gap-4 relative transition-all hover:shadow hover:border-slate-700 ${
                            isHighRisk ? 'border-l-4 border-l-rose-500' : isMidRisk ? 'border-l-4 border-l-amber-500' : 'border-l-4 border-l-emerald-400'
                          }`}
                        >
                          {/* Line 1: Comment meta info labels */}
                          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                            <span className="text-slate-550 text-xs font-mono font-medium shrink-0">#{com.id.slice(-5)}</span>
                            
                            {/* Risk Status badge */}
                            <span className={`text-xs font-extrabold px-2.5 py-0.5 rounded-full shrink-0 ${
                              isHighRisk 
                                ? 'bg-rose-950/30 border border-rose-900 text-rose-300' 
                                : isMidRisk 
                                  ? 'bg-amber-955/30 border border-amber-900 text-amber-300' 
                                  : 'bg-emerald-955/30 border border-emerald-900 text-emerald-300'
                            }`}>
                              {isHighRisk ? '高风险' : isMidRisk ? '中风险' : '低风险'}
                            </span>

                            {/* Emotion Label badge */}
                            <span className="bg-slate-800 border border-slate-700 text-slate-300 text-xs font-bold px-2.5 py-0.5 rounded-full font-sans shrink-0">
                              情感: {com.emotion}
                            </span>

                            {/* Explanation label */}
                            <span className="text-xs bg-blue-950/40 border border-blue-900/40 text-blue-300 font-bold px-2 py-0.5 rounded truncate max-w-[130px] sm:max-w-none" title={com.explanation}>
                              标签: {com.explanation}
                            </span>

                            {/* Confidence metric indicator */}
                            <div className="flex items-center gap-1 text-[11px] font-mono text-slate-500 shrink-0">
                              <span>置信度:</span>
                              <span className={`font-bold ${isLowConfidence ? 'text-red-400 font-extrabold' : 'text-slate-300'}`}>
                                {com.confidence}%
                              </span>
                            </div>

                            {/* Ethics Label Pending badges inside layout flow */}
                            {isLowConfidence && (
                              <div className="bg-red-955/40 font-mono text-[10px] font-bold border border-red-900/50 text-red-400 px-2 py-0.5 rounded-full flex items-center gap-1 animate-pulse shrink-0">
                                <AlertTriangle className="w-3 h-3 shrink-0" />
                                <span>待复核</span>
                              </div>
                            )}

                            {com.appealed && (
                              <div className="bg-cyan-955/40 font-mono text-[10px] font-bold border border-cyan-900/50 text-cyan-400 px-2 py-0.5 rounded-full flex items-center gap-1 shrink-0">
                                <Scale className="w-3 h-3 shrink-0" />
                                <span>{com.appealStatus === 'resolved' ? '已处理' : '申诉中'}</span>
                              </div>
                            )}
                          </div>

                          {/* Line 2: Original body text */}
                          <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-3.5 sm:p-4 text-xs tracking-wide leading-relaxed font-medium min-w-0">
                            <span className="text-[10px] text-slate-500 font-bold block mb-1">原始涉评文本:</span>
                            <p className="text-slate-200 font-medium break-all">{com.originalText}</p>
                          </div>

                          {/* Line 3: Rewrite Guide recommendation */}
                          {(com.rewrittenText && com.rewrittenText !== com.originalText) && (
                            <div className="bg-emerald-950/20 border border-emerald-900/30 rounded-xl p-3.5 sm:p-4 text-xs tracking-wide leading-relaxed relative group min-w-0">
                              <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1 mb-1">
                                <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" /> 智能导向矫正推荐 (AI)：
                              </span>
                              <p className="text-slate-100 italic font-semibold break-all">“{com.rewrittenText}”</p>
                              
                              <button
                                onClick={() => copyToClipboard(com.rewrittenText)}
                                className="absolute right-3.5 bottom-3 text-slate-500 hover:text-blue-400 cursor-pointer block sm:hidden sm:group-hover:block"
                              >
                                <Copy className="w-4 h-4" />
                              </button>
                            </div>
                          )}

                          {/* Line 4: Settle appeal summary description if resolved */}
                          {com.appealStatus === 'resolved' && (
                            <div className="bg-teal-950/20 border border-teal-900/30 p-3.5 rounded-xl text-xs text-teal-300">
                              <h4 className="font-bold flex items-center gap-1.5 mb-1 text-teal-400 border-b border-teal-900/30 pb-1">
                                <Scale className="w-4 h-4 text-teal-400" /> <span>申诉工单办结回复：</span>
                              </h4>
                              <p className="font-medium italic text-[11px] text-slate-300 break-all">{com.appealReason}</p>
                            </div>
                          )}

                          {/* Action footer triggers */}
                          <div className="border-t border-slate-800 pt-3.5 flex justify-end gap-3.5">
                            <button
                              onClick={() => {
                                setEditComment(com);
                                setEditedRisk(com.riskLevel);
                                setEditedEmotion(com.emotion);
                                setEditedExplanation(com.explanation);
                                setEditedRewriteText(com.rewrittenText || com.originalText);
                              }}
                              className="text-xs font-bold text-blue-400 hover:text-blue-300 flex items-center gap-1 transition-colors cursor-pointer"
                            >
                              <Edit3 className="w-4 h-4" /> <span>人工二次修正</span>
                            </button>

                            {!com.appealed && (
                              <button
                                onClick={() => {
                                  setAppealComment(com);
                                  setAppealReason('');
                                }}
                                className="text-xs font-bold text-slate-400 hover:text-red-400 flex items-center gap-1 transition-colors cursor-pointer shrink-0"
                              >
                                <AlertTriangle className="w-4 h-4 shrink-0" /> <span>发起申诉工单</span>
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </>
          )}

          {/* TAB 2: PENDING REVIEW WORKSPACE */}
          {activeTab === 'pending' && (
            <div className="space-y-4">
              <div className="bg-amber-955/20 p-4 rounded-xl border border-amber-900/30 text-xs text-amber-200 flex gap-2 leading-relaxed">
                <Info className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <p>
                  <strong>伦理透明机制：</strong>根据本系统的风控伦理规范，每条评论的 AI 判定结果如果置信度低于 <strong>70%</strong>，将自动判定为“低可信度决策”并暂扣在“待审核区域”，必须经过人工复核修改，核准后才可对外分发或输出。
                </p>
              </div>

              {pendingReviews.length === 0 ? (
                <div className="bg-slate-900 rounded-2xl border border-slate-800 p-12 text-center text-slate-400">
                  <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
                  <h3 className="font-bold text-slate-100 text-sm">暂无待复核的决策</h3>
                  <p className="text-xs mt-1 text-slate-500">目前所有 AI 分级决策的置信度均高于伦理警戒线，没有风险堆积。</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {pendingReviews.map((item) => (
                    <div key={item.comment.id} className="bg-slate-900 rounded-2xl border border-slate-800 p-4 sm:p-5 shadow-sm space-y-4 hover:border-amber-500 transition-colors">
                      <div className="flex justify-between items-start gap-4">
                        <div>
                          <span className="text-[10px] bg-amber-955/35 text-amber-300 border border-amber-900/40 px-2 py-0.5 rounded-full font-bold font-mono text-center">
                            AI 置信率: {item.comment.confidence}%
                          </span>
                          <h4 className="text-slate-100 font-bold text-xs mt-1.5 break-all">隶属新闻：《{item.articleTitle}》</h4>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-slate-950 p-3 rounded-xl border border-slate-850 text-xs min-w-0">
                          <span className="text-[10px] text-slate-500 font-bold block mb-1">原始涉评文本:</span>
                          <p className="text-slate-200 font-medium break-all">{item.comment.originalText}</p>
                        </div>
                        <div className="bg-emerald-950/20 p-3 rounded-xl border border-emerald-900/30 text-xs min-w-0">
                          <span className="text-[10px] text-emerald-400 font-bold block mb-1">AI 推荐的修正选项:</span>
                          <p className="text-slate-100 italic break-all">“{item.comment.rewrittenText}”</p>
                        </div>
                      </div>

                      <div className="border-t border-slate-805 pt-3 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-slate-950 -mx-4 sm:-mx-5 -mb-4 sm:-mb-5 p-4 sm:p-5 rounded-b-2xl">
                        <span className="text-xs font-mono text-slate-550 break-all">暂标记标签为: {item.comment.explanation}</span>
                        <button
                          onClick={() => {
                            // Load edit modal
                            setActiveArticle(articlesList.find(a => a.id === item.articleId));
                            setEditComment(item.comment);
                            setEditedRisk(item.comment.riskLevel);
                            setEditedEmotion(item.comment.emotion);
                            setEditedExplanation(item.comment.explanation);
                            setEditedRewriteText(item.comment.rewrittenText || item.comment.originalText);
                          }}
                          className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold py-1.5 px-3 rounded-lg transition-all flex items-center gap-1 cursor-pointer shrink-0"
                        >
                          <Edit3 className="w-3.5 h-3.5 shrink-0" /> <span>立刻人工会审</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: USER DEFENDED APPEALS PORTAL */}
          {activeTab === 'appeals' && (
            <div className="space-y-4">
              <div className="bg-emerald-950/20 p-4 rounded-xl border border-emerald-900/40 text-xs text-emerald-200 flex gap-2">
                <Info className="w-4.5 h-4.5 text-emerald-400 shrink-0 mt-0.5" />
                <p>
                  <strong>争议申诉中心：</strong>用户（网民）对 AI 人机内容定级及导向判罚持有异议时，可直接发起纠纷工单申请。在此您可以审核用户的申诉理由，支持一键还原评论或人工深度修订修正文本，并在线回复办结通知。
                </p>
              </div>

              {appealsList.length === 0 ? (
                <div className="bg-slate-900 rounded-2xl border border-slate-800 p-12 text-center text-slate-400">
                  <Scale className="w-12 h-12 text-slate-650 mx-auto mb-2" />
                  <h3 className="font-bold text-slate-100 text-sm">暂无活跃的申诉纠纷工单</h3>
                  <p className="text-xs mt-1 text-slate-500">目前网民对所有 AI 审计判罚持有赞同，舆论引导良好。</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {appealsList.map((app) => {
                    const isPending = app.status === 'pending';
                    return (
                      <div key={app.id} className="bg-slate-900 rounded-2xl border border-slate-800 p-4 sm:p-5 shadow-sm space-y-4 font-sans">
                        <div className="flex flex-wrap justify-between items-center gap-2 border-b border-slate-800 pb-3">
                          <div className="flex flex-wrap items-center gap-2 min-w-0">
                            <span className="text-xs font-mono font-bold text-slate-500">#{app.id}</span>
                            <span className="text-[10px] font-mono text-slate-400">{new Date(app.createdAt).toLocaleString()}</span>
                          </div>

                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 ${
                            isPending ? 'bg-amber-955/30 text-amber-300 border border-amber-900/50' : 'bg-emerald-955/30 text-emerald-300'
                          }`}>
                            {isPending ? '待办结' : '已办结'}
                          </span>
                        </div>

                        <div className="space-y-2">
                          <div className="bg-slate-950 p-3 rounded-xl text-xs space-y-1 border border-slate-850 min-w-0">
                            <span className="text-[10px] text-slate-500 font-bold block">评论原始涉评文本:</span>
                            <p className="text-slate-200 font-medium break-all">“{app.commentText}”</p>
                          </div>

                          <div className="bg-red-955/15 p-3 rounded-xl text-xs space-y-1 border border-red-900/30 min-w-0">
                            <span className="text-[10px] text-red-400 font-bold block">网民申诉抗辩缘由:</span>
                            <p className="text-slate-200 font-medium italic break-all">“{app.reason}”</p>
                          </div>
                        </div>

                        {isPending ? (
                          <div className="bg-slate-950 p-4 border border-slate-800 rounded-xl space-y-3.5">
                            <h4 className="text-xs font-bold text-slate-200">人工复审决策处理面板</h4>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div>
                                <label className="block text-[11px] font-semibold text-slate-500 mb-1">拟调整安全风险等级</label>
                                <select
                                  value={appealUpdateRisk}
                                  onChange={(e: any) => setAppealUpdateRisk(e.target.value)}
                                  className="w-full p-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-100"
                                >
                                  <option value="low">低风险 (撤销限制)</option>
                                  <option value="middle">中风险 (轻度限制)</option>
                                  <option value="high">高风险 (维持原判定)</option>
                                </select>
                              </div>
                              <div>
                                <label className="block text-[11px] font-semibold text-slate-500 mb-1">纠偏修正内容 (可在此修改)</label>
                                <input
                                  type="text"
                                  value={appealUpdateRewrite}
                                  onChange={(e) => setAppealUpdateRewrite(e.target.value)}
                                  placeholder="留空则不作修正建议"
                                  className="w-full p-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-100 placeholder:text-slate-600"
                                />
                              </div>
                            </div>

                            <div>
                              <label className="block text-[11px] font-semibold text-slate-500 mb-1">争议申诉复查答复内容 (必填)</label>
                              <textarea
                                value={appealResultText}
                                onChange={(e) => setAppealResultText(e.target.value)}
                                rows={2}
                                placeholder="输入您对本词条的判定，例如：经复核撤换低置信定级，原始发言已予以还原；或经复核原发言保留侮辱词汇，予以维持判定。"
                                className="w-full p-2 bg-slate-905 border border-slate-800 rounded-lg text-xs text-slate-100 placeholder:text-slate-600"
                              />
                            </div>

                            <div className="flex justify-end gap-2.5">
                              <button
                                onClick={() => handleResolveAppeal(app.id)}
                                disabled={!appealResultText}
                                className="bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-800 disabled:text-slate-500 disabled:cursor-not-allowed text-white text-xs font-bold py-2 px-4 rounded-xl shadow-md transition-all cursor-pointer"
                              >
                                确定结案回复
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="bg-teal-950/20 border border-teal-900/30 p-3.5 rounded-xl text-xs space-y-1">
                            <span className="text-[10px] text-teal-400 font-bold block">裁决答复已结案:</span>
                            <p className="text-slate-200 font-medium">“{app.result}”</p>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

        </section>
      </main>

      {/* FOOTER COOPERATIVE */}
      <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 py-6 mt-12 text-center text-xs">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p>© 2026 智审通 - 可靠新闻内容智能合规评析与矫正分级系统.</p>
          <p className="font-mono text-[10px] text-slate-500">POWERED BY GOOGLE AI STUDIO BUILD & GEMINI 3.5</p>
        </div>
      </footer>

      {/* 2. MODAL FOR COMMENT MODIFIER (人工优化修改弹框) */}
      {editComment && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-slate-900 rounded-3xl w-full max-w-2xl p-4 sm:p-6 shadow-2xl border border-slate-800 flex flex-col gap-5 max-h-[90vh] overflow-y-auto animate-scaleUp">
            
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-slate-100 font-extrabold text-base flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-blue-400" /> 人工会审调平修饰
              </h3>
              <button 
                onClick={() => setEditComment(null)} 
                className="text-slate-555 hover:text-slate-350 font-bold text-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Comment details */}
            <div className="space-y-3">
              <div className="bg-slate-950 p-3.5 rounded-xl text-xs border border-slate-850 min-w-0">
                <span className="font-bold text-slate-500 text-[10px] block mb-1">待审原涉评发言：</span>
                <p className="text-slate-200 font-medium break-all">“{editComment.originalText}”</p>
              </div>

              {/* Grid selectors */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-450 mb-1.5">重拟合风险等级</label>
                  <div className="flex gap-2">
                    {['low', 'middle', 'high'].map((level) => (
                      <button
                        key={level}
                        type="button"
                        onClick={() => setEditedRisk(level as any)}
                        className={`flex-1 py-1.5 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                          editedRisk === level
                            ? level === 'high'
                              ? 'bg-red-650 text-white border-red-650 shadow'
                              : level === 'middle'
                                ? 'bg-amber-500 text-white border-amber-500 shadow'
                                : 'bg-emerald-600 text-white border-emerald-600 shadow'
                            : 'bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-850'
                        }`}
                      >
                        {level === 'high' ? '高' : level === 'middle' ? '中' : '低'}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-450 mb-1.5">重拟合情感类型</label>
                  <select
                    value={editedEmotion}
                    onChange={(e: any) => setEditedEmotion(e.target.value)}
                    className="w-full p-2 bg-slate-950 border border-slate-805 rounded-lg text-xs text-slate-200 focus:ring-2 focus:ring-blue-500/20"
                  >
                    <option value="正面">正面</option>
                    <option value="中性">中性</option>
                    <option value="消极">消极</option>
                    <option value="极端偏激">极端偏激</option>
                  </select>
                </div>
              </div>

              {/* Tag labels */}
              <div>
                <label className="block text-xs font-semibold text-slate-450 mb-1">标签类型 (例如：阴阳怪气、理性支持)</label>
                <input
                  type="text"
                  value={editedExplanation}
                  onChange={(e) => setEditedExplanation(e.target.value)}
                  className="w-full p-2 bg-slate-950 border border-slate-805 rounded-lg text-xs font-medium text-slate-200 focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              {/* Text editor */}
              <div>
                <label className="block text-xs font-semibold text-slate-450 mb-1">导向矫正修正建议案内容 (拟输出的版本)</label>
                <textarea
                  value={editedRewriteText}
                  onChange={(e) => setEditedRewriteText(e.target.value)}
                  rows={3}
                  className="w-full p-2 bg-slate-950 border border-slate-805 rounded-lg text-xs font-medium text-slate-200 focus:ring-2 focus:ring-blue-500/20"
                />
              </div>
            </div>

            <div className="border-t border-slate-800 pt-3 flex justify-end gap-2.5">
              <button
                onClick={() => setEditComment(null)}
                className="py-1.5 px-4 bg-slate-800 hover:bg-slate-750 text-slate-350 text-xs font-semibold rounded-xl transition-all cursor-pointer"
              >
                取消
              </button>
              <button
                onClick={handleSaveEdit}
                className="py-1.5 px-5 bg-blue-600 hover:bg-blue-750 text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer"
              >
                核准并保存
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. MODAL FOR APPEALING DISPUTE (发起抗辩结案弹框) */}
      {appealComment && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-slate-900 rounded-3xl w-full max-w-lg p-4 sm:p-6 shadow-2xl border border-slate-800 flex flex-col gap-4 max-h-[90vh] overflow-y-auto animate-scaleUp">
            
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-slate-100 font-extrabold text-base flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-400" /> 用户内容归口申诉
              </h3>
              <button 
                onClick={() => setAppealComment(null)} 
                className="text-slate-555 hover:text-slate-355 font-bold text-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-850 text-xs min-w-0">
                <span className="text-slate-500 text-[10px] font-bold block mb-1">争议定级原涉评发言：</span>
                <p className="text-slate-200 font-medium font-sans break-all">“{appealComment.originalText}”</p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-450 mb-1.5">提出抗辩的论理诉求原因 (请写明为何此言论不具备高级风控属性)</label>
                <textarea
                  value={appealReason}
                  onChange={(e) => setAppealReason(e.target.value)}
                  rows={4}
                  required
                  placeholder="例如：我这是对公共服务的建设性质疑，并非恶心咒骂，不符合极端偏激情绪模型；请修正回正常言论。"
                  className="w-full p-2 bg-slate-955 border border-slate-800 rounded-lg text-xs text-slate-100 focus:ring-2 focus:ring-blue-500/20 placeholder:text-slate-655"
                />
              </div>
            </div>

            <div className="border-t border-slate-800 pt-3 flex justify-end gap-2.5">
              <button
                onClick={() => setAppealComment(null)}
                className="py-1.5 px-4 bg-slate-800 hover:bg-slate-755 text-slate-350 text-xs font-semibold rounded-xl transition-all cursor-pointer"
              >
                取消
              </button>
              <button
                onClick={handleCreateAppeal}
                disabled={!appealReason}
                className="py-1.5 px-4 bg-blue-600 hover:bg-blue-750 disabled:bg-slate-800 disabled:text-slate-600 disabled:cursor-not-allowed text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer"
              >
                提交争议工单
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 4. MODAL FOR ETHICAL CONSENT (伦理知情同意书) */}
      {showConsentModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-slate-900 rounded-3xl w-full max-w-2xl p-4 sm:p-6 shadow-2xl border border-slate-800 flex flex-col gap-5 max-h-[90vh] overflow-y-auto animate-scaleUp">
            
            <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
              <div className="bg-blue-950/40 p-2 rounded-xl text-blue-400 border border-blue-900/40 shrink-0">
                <Shield className="w-6 h-6 stroke-[2]" />
              </div>
              <div>
                <h3 className="text-slate-100 font-extrabold text-base">“智审通” 算法使用及伦理知情同意书</h3>
                <span className="text-[10px] text-slate-500 font-semibold uppercase font-mono tracking-wider">Ethical Transparency Declaration v1.0</span>
              </div>
            </div>

            <div className="text-xs text-slate-300 space-y-3 overflow-y-auto max-h-[300px] pr-1 leading-relaxed">
              <p>
                尊敬的用户，在使用本系统的智能抓取与 AI 舆论评价功能前，请您认真阅读下述有关数据安全、隐私及机器自动决策规则说明：
              </p>
              
              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-850 space-y-2">
                <h4 className="font-bold text-slate-200 text-[11px] flex items-center gap-1">
                  <CheckCircle className="w-3.5 h-3.5 text-blue-400" /> 一、公开数据源抓取与robots.txt限制
                </h4>
                <p className="text-[11px] text-slate-400">
                  本系统在抓取用户输入的新闻评论时，遵循了公开可见内容的无登录抓取方案。系统将遵守互联网标准 robots.txt，限制每次抓取运行的服务器请求间隔在 <strong>1(一) 秒以上</strong>，以避免对目标服务节点造成任何流量压力。
                </p>
              </div>

              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-850 space-y-2">
                <h4 className="font-bold text-slate-200 text-[11px] flex items-center gap-1">
                  <Sliders className="w-3.5 h-3.5 text-blue-400" /> 二、AI 自动化评级与置信度伦理警戒线
                </h4>
                <p className="text-[11px] text-slate-400">
                  系统集成 Google Gemini 3.5 智能模型对评论语气进行分类。算法具有一定随机度。系统设定了 <strong>70%</strong> 置信率伦理红线，凡是置信率低于此警戒线的词条，系统必须强制将其转至“待人工复核”挂起队列中，拒绝由算法单独直接结案。
                </p>
              </div>

              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-850 space-y-2">
                <h4 className="font-bold text-slate-200 text-[11px] flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5 text-blue-400" /> 三、网民权益申诉通道机制
                </h4>
                <p className="text-[11px] text-slate-400">
                  如果评论作者对 AI 定级及纠偏改写心存不满，随时可针对特定言论创建反向申诉纠纷工单。人工复核专家可以随时对决定予以撤消或核准办结，以此构筑可靠的网民言论保障机制。
                </p>
              </div>
              
              <p className="text-slate-400">
                当您点击下方的“我已知晓并同意协议”按钮并使用此应用，即代表您承诺已经仔细阅读、理解并同意上述全部伦理条款规定。
              </p>
            </div>

            <div className="border-t border-slate-800 pt-3 flex justify-end gap-3 close-btn">
              <button
                onClick={handleGrantConsent}
                className="w-full sm:w-auto py-2.5 px-6 bg-blue-600 hover:bg-blue-750 text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer uppercase flex items-center justify-center gap-1.5"
              >
                <span>我已知晓并同意协议</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
