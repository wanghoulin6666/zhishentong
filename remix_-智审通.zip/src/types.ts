/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CommentItem {
  id: string;
  originalText: string;
  emotion: '正面' | '中性' | '消极' | '极端偏激';
  riskLevel: 'low' | 'middle' | 'high';
  confidence: number; // 0 - 100
  explanation: string;
  rewrittenText: string;
  status: 'approved' | 'modified' | 'pending_review';
  appealed?: boolean;
  appealReason?: string;
  appealStatus?: 'pending' | 'resolved';
}

export interface NewsArticle {
  id: string;
  url: string;
  title: string;
  createdAt: string;
  comments: CommentItem[];
}

export interface AppealTicket {
  id: string;
  commentId: string;
  newsId: string;
  commentText: string;
  reason: string;
  status: 'pending' | 'resolved';
  result?: string;
  createdAt: string;
}
