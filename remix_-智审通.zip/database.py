# -*- coding: utf-8 -*-
"""
@license
SPDX-License-Identifier: Apache-2.0
"""
import sqlite3
import os

DB_FILE = "zhishentong.db"

def get_connection():
    """获取数据库连接"""
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row  # 允许字典型检索
    return conn

def init_db():
    """初始化 SQLite 数据库与表格"""
    conn = get_connection()
    cursor = conn.cursor()
    
    # 1. 评论所属新闻文章表
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS articles (
        id TEXT PRIMARY KEY,
        url TEXT NOT NULL,
        title TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # 2. 评论判定数据表
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS comments (
        id TEXT PRIMARY KEY,
        article_id TEXT NOT NULL,
        original_text TEXT NOT NULL,
        emotion TEXT NOT NULL,
        risk_level TEXT NOT NULL,
        confidence INTEGER NOT NULL,
        explanation TEXT,
        rewritten_text TEXT,
        status TEXT DEFAULT 'approved', -- approved, modified, pending_review
        appealed INTEGER DEFAULT 0,     -- 0=否, 1=是
        appeal_reason TEXT,
        appeal_status TEXT,             -- pending, resolved
        FOREIGN KEY (article_id) REFERENCES articles(id) ON DELETE CASCADE
    )
    """)

    # 3. 申诉维权工单表
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS appeals (
        id TEXT PRIMARY KEY,
        comment_id TEXT NOT NULL,
        news_id TEXT NOT NULL,
        comment_text TEXT NOT NULL,
        reason TEXT NOT NULL,
        status TEXT DEFAULT 'pending',  -- pending, resolved
        result TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (comment_id) REFERENCES comments(id) ON DELETE CASCADE,
        FOREIGN KEY (news_id) REFERENCES articles(id) ON DELETE CASCADE
    )
    """)

    conn.commit()
    conn.close()
    print("SQLite 数据库初始化成功！")

# ----------------- CRUD 核心操作 -----------------

def create_article(article_id, url, title):
    conn = get_connection()
    try:
        conn.execute(
            "INSERT INTO articles (id, url, title) VALUES (?, ?, ?)",
            (article_id, url, title)
        )
        conn.commit()
    finally:
        conn.close()

def get_article(article_id):
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM articles WHERE id = ?", (article_id,)).fetchone()
        if row:
            return dict(row)
        return None
    finally:
        conn.close()

def get_all_articles():
    conn = get_connection()
    try:
        rows = conn.execute("SELECT * FROM articles ORDER BY created_at DESC").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def create_comment(comment_id, article_id, original_text, emotion, risk_level, confidence, explanation, rewritten_text, status='approved'):
    conn = get_connection()
    try:
        conn.execute(
            """INSERT INTO comments 
               (id, article_id, original_text, emotion, risk_level, confidence, explanation, rewritten_text, status) 
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (comment_id, article_id, original_text, emotion, risk_level, confidence, explanation, rewritten_text, status)
        )
        conn.commit()
    finally:
        conn.close()

def get_article_comments(article_id):
    conn = get_connection()
    try:
        rows = conn.execute("SELECT * FROM comments WHERE article_id = ?", (article_id,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def update_comment_audit(comment_id, risk_level, emotion, rewritten_text, explanation):
    conn = get_connection()
    try:
        conn.execute(
            """UPDATE comments 
               SET risk_level = ?, emotion = ?, rewritten_text = ?, explanation = ?, status = 'modified' 
               WHERE id = ?""",
            (risk_level, emotion, rewritten_text, explanation, comment_id)
        )
        conn.commit()
    finally:
        conn.close()

def get_pending_reviews():
    """获取所有低于伦理警戒线置信度（< 70）或挂起待审的评论"""
    conn = get_connection()
    try:
        rows = conn.execute(
            """SELECT c.*, a.title as article_title, a.url as article_url
               FROM comments c
               JOIN articles a ON c.article_id = a.id
               WHERE c.status = 'pending_review' OR c.confidence < 70"""
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def create_appeal(appeal_id, comment_id, news_id, comment_text, reason):
    """提交申诉并标记对应评论"""
    conn = get_connection()
    try:
        conn.execute(
            """INSERT INTO appeals (id, comment_id, news_id, comment_text, reason, status) 
               VALUES (?, ?, ?, ?, ?, 'pending')""",
            (appeal_id, comment_id, news_id, comment_text, reason)
        )
        conn.execute(
            """UPDATE comments 
               SET appealed = 1, appeal_status = 'pending', appeal_reason = ? 
               WHERE id = ?""",
            (reason, comment_id)
        )
        conn.commit()
    finally:
        conn.close()

def get_all_appeals():
    conn = get_connection()
    try:
        rows = conn.execute("SELECT * FROM appeals ORDER BY created_at DESC").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def resolve_appeal(appeal_id, comment_id, news_id, result, update_risk, update_rewrite):
    """人工办结申诉"""
    conn = get_connection()
    try:
        # 更新工单状态
        conn.execute(
            "UPDATE appeals SET status = 'resolved', result = ? WHERE id = ?",
            (result, appeal_id)
        )
        # 更新原评论状态
        conn.execute(
            """UPDATE comments 
               SET appeal_status = 'resolved', risk_level = ?, rewritten_text = ?, status = 'modified'
               WHERE id = ?""",
            (update_risk, update_rewrite, comment_id)
        )
        conn.commit()
    finally:
        conn.close()
