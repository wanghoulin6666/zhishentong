# -*- coding: utf-8 -*-
"""
@license
SPDX-License-Identifier: Apache-2.0
"""
import os
import json
import time
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

# 初始化 API Key
api_key = os.environ.get("GEMINI_API_KEY")
if api_key:
    genai.configure(api_key=api_key)
else:
    print("[Warning] GEMINI_API_KEY 环境变量未设置，部分 AI 调用在部署后可能会受阻！")

def analyze_single_comment(news_title: str, comment_text: str) -> dict:
    """
    调用 Google Gemini API 分析评论合规风控模型。
    自带错误重试和降级安全阀。
    """
    if not api_key:
        return {
            "emotion": "中性",
            "risk_level": "low",
            "confidence": 60,
            "explanation": "本地引擎模拟-未配置密钥",
            "rewritten_text": comment_text
        }

    # 使用推荐的高性价比、极速模型 gemini-1.5-flash
    # 注意：在独立Python部署包中，用户可以使用 gemini-1.5-flash 或者是 gemini-2.5-flash-latest
    model_name = "gemini-1.5-flash"
    
    prompt = f"""你是一位由“智审通”安全系统授权的新闻言论审查与语用矫正专家。
下面有一篇新闻标题，以及网民在该新闻下的公开评论。请全面审查该言论。

【新闻标题】: {news_title}
【网民言论】: {comment_text}

请严格按以下要求对该言论切片分析，并生成 JSON 对象返回。不允许有任何Markdown标注，直接输出代码即可。
分类特征指涉如下：
1. "emotion" (情绪类型): 必须选择且仅选择以下标签之一："正面"、"中性"、"消极"、"极端偏激"。
2. "risk_level" (合规风险定级):
   - 若包含严重的人身攻击、反社会、诽谤捏造、煽动地域歧视或暴力等属于 "high" （高风险）。
   - 若带由较强的负面主观偏见、情绪发泄、阴阳怪气、偏执对立等属于 "middle" （中风险）。
   - 若属于文明理智评论、普通疑问或正向赞同，属于 "low" （低风险，建议不作大幅度修改）。
3. "confidence" (AI 决策置信度): 整数(100%分制)，值范围为 [0, 100]，评估你自己对此次分类的可靠程度。
4. "explanation" (定型短签): 用以指出言论的主要修饰属性，例如 "理智赞同", "宣泄情绪", "阴阳怪气-高置信度", "地域歧视", "辱骂词眼" 等。
5. "rewritten_text" (导向纠偏矫正后文字): 对发言进行柔化、修正、或重组：
   - "low" 风险：保持字句微调甚至完全一致即可；
   - "middle" 风险：通过柔和词汇、中性词弱化发言中的戾气与挑衅度，将其修改为一篇更文明理性的反思或赞同；
   - "high" 风险：必须进行高级语义重组，摒弃侮辱煽动字眼，仅温和地保留其可能存在的合理诉求或将原话进行合规和谐化重建。

返回结构示例:
{{
  "emotion": "中性",
  "risk_level": "middle",
  "confidence": 85,
  "explanation": "阴阳怪气",
  "rewritten_text": "纠正后的言论文字"
}}
"""

    max_retries = 3
    for attempt in range(max_retries):
        try:
            model = genai.GenerativeModel(model_name)
            
            # 采用 JSON 模式输出，Gemini 支持 response_mime_type="application/json"
            response = model.generate_content(
                prompt,
                generation_config={"response_mime_type": "application/json"}
            )
            
            result_text = response.text.strip() if response.text else "{}"
            result_json = json.loads(result_text)
            
            return {
                "emotion": result_json.get("emotion", "中性"),
                "risk_level": result_json.get("risk_level", "low"),
                "confidence": int(result_json.get("confidence", 80)),
                "explanation": result_json.get("explanation", "文明评论"),
                "rewritten_text": result_json.get("rewritten_text", comment_text)
            }
        except Exception as e:
            print(f"[Gemini API Retry {attempt+1}/{max_retries}] 调用失败: {e}")
            if attempt < max_retries - 1:
                time.sleep(1.5)  # 限流等场景随机退避
            else:
                break

    # 兜底降级方案：确保服务不因 API 限制导致网页崩溃
    # 采用安全且智能的局部单机字符串查禁规则
    fallback_emotion = "中性"
    fallback_risk = "low"
    fallback_explanation = "本地策略兜底"
    
    # 规则1
    if any(word in comment_text for word in ["垃圾", "脑残", "无耻", "无脑", "滚", "无良", "无知", "砖家"]):
        fallback_emotion = "极端偏激"
        fallback_risk = "high"
        fallback_explanation = "检测到不文明敏感贬损词汇"
    elif any(word in comment_text for word in ["套壳", "呵呵", "吃相", "水分", "割韭菜"]):
        fallback_emotion = "消极"
        fallback_risk = "middle"
        fallback_explanation = "检测到阴阳怪气批判语系"

    return {
        "emotion": fallback_emotion,
        "risk_level": fallback_risk,
        "confidence": 65,  # 本地策略低于 70 阈值，会自动触发待人工会签机制，极为符合安全闭环！
        "explanation": fallback_explanation,
        "rewritten_text": comment_text.replace("无耻", "不妥").replace("无脑", "理智").replace("滚", "文明交流")
    }
